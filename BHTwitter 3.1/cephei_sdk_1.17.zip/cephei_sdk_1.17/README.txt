This is an SDK for developers wanting to use Cephei.

Version: 1.17

For more information, visit https://hbang.github.io/libcephei/.